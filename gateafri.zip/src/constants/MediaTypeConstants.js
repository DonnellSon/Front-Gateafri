export const SMARTPHONE = "smartphone";
export const TABLET = "tablet";
export const DESKTOP = "desktop";