import React from 'react'
import PostCard from '../../components/PostCard/PostCard'

const PageActu = () => {
  return (
    <div className='actu-page flex flex-column align-items-center'>
      <div className="post-list">
        <PostCard/>
        <PostCard/>
        <PostCard/>
        <PostCard/>
        <PostCard/>
        <PostCard/>
        <PostCard/>
      </div>
    </div>
  )
}

export default PageActu
