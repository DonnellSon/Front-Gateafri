import React from 'react'
import './WelcomeBanner.css'
import { XLg,Plus } from 'react-bootstrap-icons'
const WelcomeBanner = () => {
    return (
        <div className='welcome-banner relative'>
            <div className="text relative">
                <h6>Bonjour Donnell</h6>
                <h4>Bienvenue sur GATE AFRI,le reseau des acteurs economiques en Afrique</h4>
                <p>Veuillez créer une page professionnelle pour promouvoir vos activités.</p>
                <button><Plus size={26}/> Créer un portail</button>
            </div>
            <div className="close absolute">
                <XLg size={20}/>
            </div>
        </div>
    )
}

export default WelcomeBanner
