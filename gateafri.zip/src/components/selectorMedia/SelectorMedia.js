import React, { useState, useEffect, useRef, Component } from 'react';
import useSafeState from '../../Hooks/useSafeState';
import './selectorMedia.css';
const SelectorMedia = ({ media, removeSelf }) => {
    
    const [load, setLoad] = useSafeState(false);
    const [source, setSource] = useSafeState(null);
    const [loaded, setLoaded] = useSafeState(0);
    const self=useRef();
    const [selfWidth,setSelfWidth]=useSafeState(0);
    
    const createThumbnail = (file) => {
        const reader = new FileReader();
        reader.addEventListener('progress', (e) => {
            setLoaded(Math.ceil((e.loaded * 100) / e.total));
        });
        reader.addEventListener('load', (e) => {
            setSource(e.currentTarget.result);
            setLoad(true);
        });
        reader.readAsDataURL(file);
    }
    useEffect(() => {
        createThumbnail(media.file);
        if(self.current){
            setSelfWidth(self.current.offsetWidth)
        }
    }, [media]);
    

    return (

        <div className="relative">
            {
                (load && source != null) &&
                    (/^image/.test(media.type)) ?
                    <img src={source} alt="go" />
                    : ((/^video/.test(media.type)) ?
                        <video src={source}></video>
                        : ''
                    )

            }
            {
                !load &&
                <div ref={self} className="prog">
                    <div style={{ width: (loaded) + '%' }}>
                        <div style={{animation:'loadingBackground 1s ease infinite',width:selfWidth+'px'}}></div>
                    </div>
                    <b style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)' }}>{loaded + '%'}</b>
                </div>
            }
            <div onClick={()=>{removeSelf()}} className="remove a-center">
                <i className="bi bi-x-lg"></i>
            </div>

        </div>

    )
}

export default SelectorMedia