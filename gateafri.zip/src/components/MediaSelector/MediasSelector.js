import React, { Fragment, useState, useRef, useEffect } from 'react';
import './MediasSelector.css';
import SelectorMedia from '../selectorMedia/SelectorMedia';
const MediasSelector = ({ mediasSelected, removeMedia,gap=10,col=4 }) => {
    
    return (

        <Fragment>
            {
                (mediasSelected.length > 0) ?
                    <div className={"medias-selector square-grid"} style={{gridTemplateColumns: `repeat(${col},1fr)`,gridGap:gap+"px"}}>
                        {
                            mediasSelected.map((m, i) => {

                                return (
                                    <div key={i} style={{ animation: `scaleIn .1s ${m.delay / 10}s forwards` }} className="m-parent scaleIn">
                                        {/* <div className="relative">
                                            {
                                                
                                                    (/^image/.test(m.type)) ?
                                                    <img src={m.url} alt="go" />
                                                    : ((/^video/.test(m.type)) ?
                                                        <video src={m.url}></video>
                                                        : ''
                                                    )

                                            }
                                            
                                            <div onClick={()=>{removeMedia(i)}} className="remove">&times;</div>
                                        </div> */}
                                        <SelectorMedia media={m} removeSelf={()=>{removeMedia(i)}} />
                                    </div>
                                )
                            })
                        }

                    </div> : ''
            }
        </Fragment >

    )
}

export default MediasSelector;