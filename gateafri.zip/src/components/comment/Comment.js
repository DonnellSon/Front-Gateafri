import React,{useContext} from 'react'
import CommentContent from '../commentContent/CommentContent';
import './comment.css'
const Comment = () => {
    return (
        <div className={`comment comment-light flex relative`}>
            <div style={{width:"100%"}}>
                <div className="comment-parent">
                    <CommentContent>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque, ut? Ducimus quae, consectetur debitis molestias magni a voluptatem accusamus sequi aliquid. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</CommentContent>
                </div>
                <div className="rep-list">
                    <CommentContent>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque, ut? Ducimus quae</CommentContent>
                </div>
            </div>
        </div>
    )
}

export default Comment

