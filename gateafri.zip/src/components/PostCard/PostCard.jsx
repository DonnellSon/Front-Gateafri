import React, { useContext } from 'react'
import './PostCard.css'
import { Plus, Diamond, Gem, ChatLeft, Share } from 'react-bootstrap-icons'
import Avatar from '../Avatar/Avatar'
import CommentList from '../commentList/CommentList'
import MediaContext from '../../context/MediaContext'
import { DESKTOP, SMARTPHONE, TABLET } from '../../constants/MediaTypeConstants'
const PostCard = ({ noComment = false }) => {
  const { deviceType } = useContext(MediaContext)
  return (
    <div className='post-card'>
      <div className="top flex justify-content-between" style={{ 
        top:deviceType===DESKTOP ? 'var(--topbar-height)' : 0,
        position:deviceType===DESKTOP ? 'sticky !important' : 'statique !important',
        padding:'8px 10px',
      }}>
        <div className="left flex gap-10">
          <Avatar height={40} width={40} />
          <div className="author-info">
            <h1>Kaiza Entreprises</h1>
            <span>Il y a 1h</span>
          </div>
        </div>
        <div className="flex gap-10">
          <div className="flag">
            <img src="/img/flags/Flag_of_Algeria.svg" height={30} alt="" />
          </div>
          <div className="plus-btn"><Plus size={28} style={{ display: 'block' }} /></div>
        </div>
      </div>
      <div className="body">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo aperiam laboriosam recusandae expedita voluptatibus. Dignissimos temporibus ipsum sapiente facilis? Aperiam quod dolore, omnis eaque molestiae ipsam facilis labore. Iure, cumque!</p>
      </div>
      <div className="imgs">
        <div>
          <img src="/img/entreprises/d.jpg" alt="" />
        </div>
        <div>
          <img src="/img/entreprises/d.jpg" alt="" />
        </div>
        <div>
          <img src="/img/entreprises/d.jpg" alt="" />
        </div>
        <div>
          <img src="/img/entreprises/d.jpg" alt="" />
        </div>
      </div>
      {
        !noComment &&
        <div className="post-comment-list p-10">
          <CommentList />
        </div>
      }
      <div className="footer flex align-items-center gap-15">
        <span className='flex align-items-center gap-10 no-wrap-text'>
          <Gem size={19} /><span>Evaluer</span>
        </span>
        <span className='flex align-items-center gap-10 no-wrap-text'>
          <ChatLeft size={19} /><span>Commenter</span>
        </span>
        <span className='flex align-items-center gap-10 no-wrap-text'>
          <Share size={19} /><span>Partager</span>
        </span>
      </div>
    </div>
  )
}

export default PostCard
