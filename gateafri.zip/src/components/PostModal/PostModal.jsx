import React, { useEffect, useRef, useState } from 'react'
import './PostModal.css'
import Modal from '../Modal/Modal'
import { BarChart, BodyText, CupHot, FileEarmarkImage, GeoAlt, Hash, ChevronDown, XLg, Globe } from 'react-bootstrap-icons'
import Avatar from '../Avatar/Avatar'
import Tabs from '../Tabs/Tabs'
import Tab from '../Tabs/Tab'
import ContactTag from '../ContactTag/ContactTag'
import MediasSelector from '../MediaSelector/MediasSelector'
import Survey from '../Survey/Survey'
const PostModal = ({ isOpen = false, setIsOpen = () => { } }) => {
  
  const mediasInput=useRef()

  


  const [tmpMediasList, setTmpMediasList] = useState([]);
  const removeTmpMedia = (index) => {
    const medias = tmpMediasList.slice();
    const med = medias.filter((m, i) => i !== index);
    setTmpMediasList(med);
  }
  const addMedias = (fileArray) => {
    const files = [...tmpMediasList];
    for (let i = 0; i < fileArray.length; i++) {
      files.push({ type: fileArray[i].type, url: URL.createObjectURL(fileArray[i]), file: fileArray[i], delay: i, index: i });
    }
    setTmpMediasList(files);
  }
  const clickMediasInput = () => {
      mediasInput.current.click();
  }
  return (
    <Modal open={isOpen} onClose={(open) => setIsOpen(open)} className='post-modal'>
      <div className="heading flex align-items-center justify-content-between">
        <h3>Publication</h3>
        <XLg onClick={() => {
          setIsOpen(false)
        }} />
      </div>
      <div className="body flex flex-column flex-grow-1">
        <Tabs className='post-modal-tabs' navRight={
          <>
            <div className="audience-choice flex align-items-center gap-5"><Globe /> Public <ChevronDown /></div>
            <div className='portal-choice flex gap-5 align-items-center'>
              <span>Donnell Son</span>
              <Avatar height={25} width={25} />
              <ChevronDown />
            </div>
          </>
        }>
          <Tab title={<>
            <BodyText size={18} />
            <span>Text</span>
          </>}>
            <div contentEditable={true}>Votre texte Ici</div>
          </Tab>
          <Tab title={<div className='li flex flex-column align-items-center' onClick={clickMediasInput}>
            <FileEarmarkImage size={18} />
            <input multiple ref={mediasInput} type="file" onChange={(e) => {
              addMedias(e.target.files);
            }}
              style={{ display: 'none' }} />
            <span className='text-ellipsis' style={{ width: '100%' }}>Images/Videos</span>
          </div>
          }>

            
              <MediasSelector mediasSelected={tmpMediasList} addMedias={addMedias} removeMedia={removeTmpMedia} />
            
          </Tab>
          <Tab title={<>
            <BarChart size={18} />
            <span>Sondage</span>
          </>}>
            <Survey/>
          </Tab>
          <Tab title={<>
            <Hash size={18} />
            <span>Tags</span>
          </>}>
            <ContactTag />
          </Tab>
          <Tab title={<>
            <CupHot size={18} />
            <span>Activité</span>
          </>}>
            activity
          </Tab>
          <Tab title={
            <>
              <GeoAlt size={18} />
              <span>Lieu</span>
            </>
          }>
            Location
          </Tab>
        </Tabs>

      </div>
      <div className="footer flex align-items-center justify-content-end gap-10">
        <button className="btn-transparent" style={{ width: 120 }}>Annuler</button>
        <button className="btn-purple" style={{ width: 120 }}>Publier</button>
      </div>
    </Modal>
  )
}

export default PostModal
