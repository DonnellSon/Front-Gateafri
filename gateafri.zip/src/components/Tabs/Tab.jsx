import React from 'react'

const Tab = ({title,children}) => {
  return <></>
}

export default Tab
